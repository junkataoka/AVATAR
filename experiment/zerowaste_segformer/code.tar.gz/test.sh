#!/bin/bash
#SBATCH --job-name=AVATAR-VISDA2022
#SBATCH --output=AVATAR_VISDA_output.txt
#SBATCH --error=AVATAR_VISDA_error.log
#SBATCH --mail-type=ALL
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --partition=gpucompute
#SBATCH --mem=20GB
#SBATCH --gres=gpu:1

module load cuda11.1/toolkit/11.1.1
#TEST_ROOT=$1
#CONFIG_FILE="${TEST_ROOT}/*${TEST_ROOT: -1}.json"
#CHECKPOINT_FILE="${TEST_ROOT}/latest.pth"
#SHOW_DIR="${TEST_ROOT}/preds/"
#echo 'Config File:' $CONFIG_FILE
#echo 'Checkpoint File:' $CHECKPOINT_FILE
#echo 'Predictions Output Directory:' $SHOW_DIR
#python -m tools.test ${CONFIG_FILE} ${CHECKPOINT_FILE} --eval mIoU --show-dir ${SHOW_DIR} --opacity 1


srun python -m tools.test \
/data/home/jkataok1/visda2022-org/configs/source_only/zerowaste_to_zerowastev2_segformer_val.json \
/data/home/jkataok1/visda2022-org/pretrained/source_only_segformer_zerowaste.pth \
--eval mIoU --show-dir \
/data/home/jkataok1/visda2022-org/output/predictions \
--opacity 1
