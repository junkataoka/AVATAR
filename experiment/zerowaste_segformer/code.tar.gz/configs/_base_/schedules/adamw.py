# optimizer
optimizer = dict(
    type='AdamW', lr=0.00006, betas=(0.9, 0.999), weight_decay=0.01)
optimizer_config = dict()
