from mmseg.models.uda.dacs import DACS

__all__ = ['DACS']
