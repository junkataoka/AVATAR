#!/bin/bash
#SBATCH --job-name=AVATAR-VISDA2022
#SBATCH --output=AVATAR_VISDA_output.txt
#SBATCH --error=AVATAR_VISDA_error.log
#SBATCH --mail-type=ALL
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --partition=gpucompute
#SBATCH --mem=20GB
#SBATCH --gres=gpu:2

module load cuda11.1/toolkit/11.1.1
#TEST_ROOT=$1
#CONFIG_FILE="${TEST_ROOT}/*${TEST_ROOT: -1}.json"
#CHECKPOINT_FILE="${TEST_ROOT}/latest.pth"
#SHOW_DIR="${TEST_ROOT}/preds/"
#echo 'Config File:' $CONFIG_FILE
#echo 'Checkpoint File:' $CHECKPOINT_FILE
#echo 'Predictions Output Directory:' $SHOW_DIR
#python -m tools.test ${CONFIG_FILE} ${CHECKPOINT_FILE} --eval mIoU --show-dir ${SHOW_DIR} --opacity 1


srun python -m tools.train configs/source_only/zerowaste_to_zerowastev2_segformer.json \
--work-dir /data/home/jkataok1/AVATAR2022/experiment/zerowaste_segformer
